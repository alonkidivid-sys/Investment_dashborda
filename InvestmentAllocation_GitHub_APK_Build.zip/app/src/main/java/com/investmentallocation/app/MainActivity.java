package com.investmentallocation.app;
import android.app.Activity; import android.os.Bundle; import android.webkit.*;
public class MainActivity extends Activity {
 private WebView webView;
 @Override public void onCreate(Bundle b){super.onCreate(b); webView=new WebView(this); setContentView(webView);
 WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
 s.setAllowFileAccess(true); s.setAllowContentAccess(false); webView.setWebViewClient(new WebViewClient());
 webView.loadUrl("file:///android_asset/index.html");}
 @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}